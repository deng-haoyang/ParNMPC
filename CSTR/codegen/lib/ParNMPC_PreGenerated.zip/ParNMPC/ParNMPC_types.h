/*
 * File: ParNMPC_types.h
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 21-Jan-2018 02:06:04
 */

#ifndef PARNMPC_TYPES_H
#define PARNMPC_TYPES_H

/* Include Files */
#include "rtwtypes.h"

/* Type Definitions */
#include <stdio.h>
#endif

/*
 * File trailer for ParNMPC_types.h
 *
 * [EOF]
 */
