/*
 * File: GEN_Func_dKKT23_mu_u.h
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 21-Jan-2018 02:06:04
 */

#ifndef GEN_FUNC_DKKT23_MU_U_H
#define GEN_FUNC_DKKT23_MU_U_H

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "omp.h"
#include "ParNMPC_types.h"

/* Function Declarations */
extern void GEN_Func_dKKT23_mu_u(const double in1[14], double dKKT23_mu_u[36]);

#endif

/*
 * File trailer for GEN_Func_dKKT23_mu_u.h
 *
 * [EOF]
 */
