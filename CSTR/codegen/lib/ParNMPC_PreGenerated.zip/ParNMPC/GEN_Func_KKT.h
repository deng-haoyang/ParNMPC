/*
 * File: GEN_Func_KKT.h
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 21-Jan-2018 02:06:04
 */

#ifndef GEN_FUNC_KKT_H
#define GEN_FUNC_KKT_H

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "omp.h"
#include "ParNMPC_types.h"

/* Function Declarations */
extern void GEN_Func_KKT(const double in1[14], const double in2[4], const double
  in3[4], double KKT[14]);

#endif

/*
 * File trailer for GEN_Func_KKT.h
 *
 * [EOF]
 */
