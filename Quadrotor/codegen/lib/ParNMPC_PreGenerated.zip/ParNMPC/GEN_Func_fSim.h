/*
 * File: GEN_Func_fSim.h
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 21-Jan-2018 02:13:18
 */

#ifndef GEN_FUNC_FSIM_H
#define GEN_FUNC_FSIM_H

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "omp.h"
#include "ParNMPC_types.h"

/* Function Declarations */
extern void GEN_Func_fSim(const double in1[17], double fSim[9]);

#endif

/*
 * File trailer for GEN_Func_fSim.h
 *
 * [EOF]
 */
