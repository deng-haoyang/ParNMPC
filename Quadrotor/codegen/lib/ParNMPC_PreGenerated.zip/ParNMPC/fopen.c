/*
 * File: fopen.c
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 21-Jan-2018 02:13:18
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "ParNMPC.h"
#include "fopen.h"
#include "fileManager.h"
#include <stdio.h>
#include "omp.h"
#include "stdio.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : double
 */
double b_fopen(void)
{
  return fileManager();
}

/*
 * File trailer for fopen.c
 *
 * [EOF]
 */
