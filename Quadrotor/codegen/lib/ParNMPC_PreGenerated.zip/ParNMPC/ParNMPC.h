/*
 * File: ParNMPC.h
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 21-Jan-2018 02:13:18
 */

#ifndef PARNMPC_H
#define PARNMPC_H

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "omp.h"
#include "ParNMPC_types.h"

/* Function Declarations */
extern void ParNMPC(void);

#endif

/*
 * File trailer for ParNMPC.h
 *
 * [EOF]
 */
