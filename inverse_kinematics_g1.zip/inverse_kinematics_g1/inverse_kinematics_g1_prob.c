/* Copyright 2025, RTOPT */

#ifdef __cplusplus
extern "C" {
#endif

#include "inverse_kinematics_g1_prob.h"
#include <math.h>

void inverse_kinematics_g1_l(const Inverse_kinematics_g1_SolverInfo *_solverinfo, const Inverse_kinematics_g1_Problem *_prob, const double _var[29], const double _scaling_factor[1], double _l[1], double _jac_l[29], double _hess[435])
{
    const double q0 = _var[0];
    const double q1 = _var[1];
    const double q2 = _var[2];
    const double q3 = _var[3];
    const double q4 = _var[4];
    const double q5 = _var[5];
    const double q6 = _var[6];
    const double q7 = _var[7];
    const double q8 = _var[8];
    const double q9 = _var[9];
    const double q10 = _var[10];
    const double q11 = _var[11];
    const double q12 = _var[12];
    const double q13 = _var[13];
    const double q14 = _var[14];
    const double q15 = _var[15];
    const double q16 = _var[16];
    const double q17 = _var[17];
    const double q18 = _var[18];
    const double q19 = _var[19];
    const double q20 = _var[20];
    const double q21 = _var[21];
    const double q22 = _var[22];
    const double q23 = _var[23];
    const double q24 = _var[24];
    const double q25 = _var[25];
    const double q26 = _var[26];
    const double q27 = _var[27];
    const double q28 = _var[28];
    const double _lscaling = _scaling_factor[0];
    (void)_solverinfo;
    (void)_prob->param;
    (void)_prob->param_stage;
    const double _cse_0 = 1.0*_lscaling;
    
    if (_l != NULL) {
       _l[0] = _lscaling*(0.5*((q0)*(q0)) + 0.5*((q1)*(q1)) + 0.5*((q10)*(q10)) + 0.5*((q11)*(q11)) + 0.5*((q12)*(q12)) + 0.5*((q13)*(q13)) + 0.5*((q14)*(q14)) + 0.5*((q15)*(q15)) + 0.5*((q16)*(q16)) + 0.5*((q17)*(q17)) + 0.5*((q18)*(q18)) + 0.5*((q19)*(q19)) + 0.5*((q2)*(q2)) + 0.5*((q20)*(q20)) + 0.5*((q21)*(q21)) + 0.5*((q22)*(q22)) + 0.5*((q23)*(q23)) + 0.5*((q24)*(q24)) + 0.5*((q25)*(q25)) + 0.5*((q26)*(q26)) + 0.5*((q27)*(q27)) + 0.5*((q28)*(q28)) + 0.5*((q3)*(q3)) + 0.5*((q4)*(q4)) + 0.5*((q5)*(q5)) + 0.5*((q6)*(q6)) + 0.5*((q7)*(q7)) + 0.5*((q8)*(q8)) + 0.5*((q9)*(q9)));
    }
    
    if (_jac_l != NULL) {
       _jac_l[0] = _cse_0*q0;
       _jac_l[1] = _cse_0*q1;
       _jac_l[2] = _cse_0*q2;
       _jac_l[3] = _cse_0*q3;
       _jac_l[4] = _cse_0*q4;
       _jac_l[5] = _cse_0*q5;
       _jac_l[6] = _cse_0*q6;
       _jac_l[7] = _cse_0*q7;
       _jac_l[8] = _cse_0*q8;
       _jac_l[9] = _cse_0*q9;
       _jac_l[10] = _cse_0*q10;
       _jac_l[11] = _cse_0*q11;
       _jac_l[12] = _cse_0*q12;
       _jac_l[13] = _cse_0*q13;
       _jac_l[14] = _cse_0*q14;
       _jac_l[15] = _cse_0*q15;
       _jac_l[16] = _cse_0*q16;
       _jac_l[17] = _cse_0*q17;
       _jac_l[18] = _cse_0*q18;
       _jac_l[19] = _cse_0*q19;
       _jac_l[20] = _cse_0*q20;
       _jac_l[21] = _cse_0*q21;
       _jac_l[22] = _cse_0*q22;
       _jac_l[23] = _cse_0*q23;
       _jac_l[24] = _cse_0*q24;
       _jac_l[25] = _cse_0*q25;
       _jac_l[26] = _cse_0*q26;
       _jac_l[27] = _cse_0*q27;
       _jac_l[28] = _cse_0*q28;
    }
    
    if (_hess != NULL) {
       (void)_hess;
    }
}

void inverse_kinematics_g1_le(const Inverse_kinematics_g1_SolverInfo *_solverinfo, const Inverse_kinematics_g1_Problem *_prob, const double _var[29], const double _scaling_factor[1], double _le[1], double _jac_le[29], double _hess[435])
{
    
    (void)_solverinfo;
    (void)_prob->param;
    (void)_prob->param_stage;
    (void)_var;
    (void)_scaling_factor;
    
    
    if (_le != NULL) {
       (void)_le;
    }
    
    if (_jac_le != NULL) {
       (void)_jac_le;
    }
    
    if (_hess != NULL) {
       (void)_hess;
    }
}

void inverse_kinematics_g1_bound(const Inverse_kinematics_g1_SolverInfo *_solverinfo, const Inverse_kinematics_g1_Problem *_prob, double _lb[29], double _ub[29], double _soft_lb[29], double _soft_ub[29], double _weight_soft_lb[29], double _weight_soft_ub[29])
{
    
    (void)_solverinfo;
    (void)_prob->param;
    (void)_prob->param_stage;
    
    
    if (_lb != NULL) {
       _lb[0] = -2.5306999999999999;
       _lb[1] = -0.52359999999999995;
       _lb[2] = -2.7576000000000001;
       _lb[3] = -0.087266999999999997;
       _lb[4] = -0.87266999999999995;
       _lb[5] = -0.26179999999999998;
       _lb[6] = -2.5306999999999999;
       _lb[7] = -2.9670999999999998;
       _lb[8] = -2.7576000000000001;
       _lb[9] = -0.087266999999999997;
       _lb[10] = -0.87266999999999995;
       _lb[11] = -0.26179999999999998;
       _lb[12] = -2.6179999999999999;
       _lb[13] = -0.52000000000000002;
       _lb[14] = -0.52000000000000002;
       _lb[15] = -3.0891999999999999;
       _lb[16] = -1.5882000000000001;
       _lb[17] = -2.6179999999999999;
       _lb[18] = -1.0471999999999999;
       _lb[19] = -1.9722220500000001;
       _lb[20] = -1.61442956;
       _lb[21] = -1.61442956;
       _lb[22] = -3.0891999999999999;
       _lb[23] = -2.2515000000000001;
       _lb[24] = -2.6179999999999999;
       _lb[25] = -1.0471999999999999;
       _lb[26] = -1.9722220500000001;
       _lb[27] = -1.61442956;
       _lb[28] = -1.61442956;
    }
    
    if (_ub != NULL) {
       _ub[0] = 2.8797999999999999;
       _ub[1] = 2.9670999999999998;
       _ub[2] = 2.7576000000000001;
       _ub[3] = 2.8797999999999999;
       _ub[4] = 0.52359999999999995;
       _ub[5] = 0.26179999999999998;
       _ub[6] = 2.8797999999999999;
       _ub[7] = 0.52359999999999995;
       _ub[8] = 2.7576000000000001;
       _ub[9] = 2.8797999999999999;
       _ub[10] = 0.52359999999999995;
       _ub[11] = 0.26179999999999998;
       _ub[12] = 2.6179999999999999;
       _ub[13] = 0.52000000000000002;
       _ub[14] = 0.52000000000000002;
       _ub[15] = 2.6703999999999999;
       _ub[16] = 2.2515000000000001;
       _ub[17] = 2.6179999999999999;
       _ub[18] = 2.0943999999999998;
       _ub[19] = 1.9722220500000001;
       _ub[20] = 1.61442956;
       _ub[21] = 1.61442956;
       _ub[22] = 2.6703999999999999;
       _ub[23] = 1.5882000000000001;
       _ub[24] = 2.6179999999999999;
       _ub[25] = 2.0943999999999998;
       _ub[26] = 1.9722220500000001;
       _ub[27] = 1.61442956;
       _ub[28] = 1.61442956;
    }
    
    if (_soft_lb != NULL) {
       _soft_lb[0] = -HUGE_VAL;
       _soft_lb[1] = -HUGE_VAL;
       _soft_lb[2] = -HUGE_VAL;
       _soft_lb[3] = -HUGE_VAL;
       _soft_lb[4] = -HUGE_VAL;
       _soft_lb[5] = -HUGE_VAL;
       _soft_lb[6] = -HUGE_VAL;
       _soft_lb[7] = -HUGE_VAL;
       _soft_lb[8] = -HUGE_VAL;
       _soft_lb[9] = -HUGE_VAL;
       _soft_lb[10] = -HUGE_VAL;
       _soft_lb[11] = -HUGE_VAL;
       _soft_lb[12] = -HUGE_VAL;
       _soft_lb[13] = -HUGE_VAL;
       _soft_lb[14] = -HUGE_VAL;
       _soft_lb[15] = -HUGE_VAL;
       _soft_lb[16] = -HUGE_VAL;
       _soft_lb[17] = -HUGE_VAL;
       _soft_lb[18] = -HUGE_VAL;
       _soft_lb[19] = -HUGE_VAL;
       _soft_lb[20] = -HUGE_VAL;
       _soft_lb[21] = -HUGE_VAL;
       _soft_lb[22] = -HUGE_VAL;
       _soft_lb[23] = -HUGE_VAL;
       _soft_lb[24] = -HUGE_VAL;
       _soft_lb[25] = -HUGE_VAL;
       _soft_lb[26] = -HUGE_VAL;
       _soft_lb[27] = -HUGE_VAL;
       _soft_lb[28] = -HUGE_VAL;
    }
    
    if (_soft_ub != NULL) {
       _soft_ub[0] = HUGE_VAL;
       _soft_ub[1] = HUGE_VAL;
       _soft_ub[2] = HUGE_VAL;
       _soft_ub[3] = HUGE_VAL;
       _soft_ub[4] = HUGE_VAL;
       _soft_ub[5] = HUGE_VAL;
       _soft_ub[6] = HUGE_VAL;
       _soft_ub[7] = HUGE_VAL;
       _soft_ub[8] = HUGE_VAL;
       _soft_ub[9] = HUGE_VAL;
       _soft_ub[10] = HUGE_VAL;
       _soft_ub[11] = HUGE_VAL;
       _soft_ub[12] = HUGE_VAL;
       _soft_ub[13] = HUGE_VAL;
       _soft_ub[14] = HUGE_VAL;
       _soft_ub[15] = HUGE_VAL;
       _soft_ub[16] = HUGE_VAL;
       _soft_ub[17] = HUGE_VAL;
       _soft_ub[18] = HUGE_VAL;
       _soft_ub[19] = HUGE_VAL;
       _soft_ub[20] = HUGE_VAL;
       _soft_ub[21] = HUGE_VAL;
       _soft_ub[22] = HUGE_VAL;
       _soft_ub[23] = HUGE_VAL;
       _soft_ub[24] = HUGE_VAL;
       _soft_ub[25] = HUGE_VAL;
       _soft_ub[26] = HUGE_VAL;
       _soft_ub[27] = HUGE_VAL;
       _soft_ub[28] = HUGE_VAL;
    }
    
    if (_weight_soft_lb != NULL) {
       _weight_soft_lb[0] = 0.0;
       _weight_soft_lb[1] = 0.0;
       _weight_soft_lb[2] = 0.0;
       _weight_soft_lb[3] = 0.0;
       _weight_soft_lb[4] = 0.0;
       _weight_soft_lb[5] = 0.0;
       _weight_soft_lb[6] = 0.0;
       _weight_soft_lb[7] = 0.0;
       _weight_soft_lb[8] = 0.0;
       _weight_soft_lb[9] = 0.0;
       _weight_soft_lb[10] = 0.0;
       _weight_soft_lb[11] = 0.0;
       _weight_soft_lb[12] = 0.0;
       _weight_soft_lb[13] = 0.0;
       _weight_soft_lb[14] = 0.0;
       _weight_soft_lb[15] = 0.0;
       _weight_soft_lb[16] = 0.0;
       _weight_soft_lb[17] = 0.0;
       _weight_soft_lb[18] = 0.0;
       _weight_soft_lb[19] = 0.0;
       _weight_soft_lb[20] = 0.0;
       _weight_soft_lb[21] = 0.0;
       _weight_soft_lb[22] = 0.0;
       _weight_soft_lb[23] = 0.0;
       _weight_soft_lb[24] = 0.0;
       _weight_soft_lb[25] = 0.0;
       _weight_soft_lb[26] = 0.0;
       _weight_soft_lb[27] = 0.0;
       _weight_soft_lb[28] = 0.0;
    }
    
    if (_weight_soft_ub != NULL) {
       _weight_soft_ub[0] = 0.0;
       _weight_soft_ub[1] = 0.0;
       _weight_soft_ub[2] = 0.0;
       _weight_soft_ub[3] = 0.0;
       _weight_soft_ub[4] = 0.0;
       _weight_soft_ub[5] = 0.0;
       _weight_soft_ub[6] = 0.0;
       _weight_soft_ub[7] = 0.0;
       _weight_soft_ub[8] = 0.0;
       _weight_soft_ub[9] = 0.0;
       _weight_soft_ub[10] = 0.0;
       _weight_soft_ub[11] = 0.0;
       _weight_soft_ub[12] = 0.0;
       _weight_soft_ub[13] = 0.0;
       _weight_soft_ub[14] = 0.0;
       _weight_soft_ub[15] = 0.0;
       _weight_soft_ub[16] = 0.0;
       _weight_soft_ub[17] = 0.0;
       _weight_soft_ub[18] = 0.0;
       _weight_soft_ub[19] = 0.0;
       _weight_soft_ub[20] = 0.0;
       _weight_soft_ub[21] = 0.0;
       _weight_soft_ub[22] = 0.0;
       _weight_soft_ub[23] = 0.0;
       _weight_soft_ub[24] = 0.0;
       _weight_soft_ub[25] = 0.0;
       _weight_soft_ub[26] = 0.0;
       _weight_soft_ub[27] = 0.0;
       _weight_soft_ub[28] = 0.0;
    }
}

void inverse_kinematics_g1_bound_soft_type(const Inverse_kinematics_g1_SolverInfo *_solverinfo, int _type_soft_lb[29], int _type_soft_ub[29])
{
    
    (void)_solverinfo;
    
    
    if (_type_soft_lb != NULL) {
       _type_soft_lb[0] = 0;
       _type_soft_lb[1] = 0;
       _type_soft_lb[2] = 0;
       _type_soft_lb[3] = 0;
       _type_soft_lb[4] = 0;
       _type_soft_lb[5] = 0;
       _type_soft_lb[6] = 0;
       _type_soft_lb[7] = 0;
       _type_soft_lb[8] = 0;
       _type_soft_lb[9] = 0;
       _type_soft_lb[10] = 0;
       _type_soft_lb[11] = 0;
       _type_soft_lb[12] = 0;
       _type_soft_lb[13] = 0;
       _type_soft_lb[14] = 0;
       _type_soft_lb[15] = 0;
       _type_soft_lb[16] = 0;
       _type_soft_lb[17] = 0;
       _type_soft_lb[18] = 0;
       _type_soft_lb[19] = 0;
       _type_soft_lb[20] = 0;
       _type_soft_lb[21] = 0;
       _type_soft_lb[22] = 0;
       _type_soft_lb[23] = 0;
       _type_soft_lb[24] = 0;
       _type_soft_lb[25] = 0;
       _type_soft_lb[26] = 0;
       _type_soft_lb[27] = 0;
       _type_soft_lb[28] = 0;
    }
    
    if (_type_soft_ub != NULL) {
       _type_soft_ub[0] = 0;
       _type_soft_ub[1] = 0;
       _type_soft_ub[2] = 0;
       _type_soft_ub[3] = 0;
       _type_soft_ub[4] = 0;
       _type_soft_ub[5] = 0;
       _type_soft_ub[6] = 0;
       _type_soft_ub[7] = 0;
       _type_soft_ub[8] = 0;
       _type_soft_ub[9] = 0;
       _type_soft_ub[10] = 0;
       _type_soft_ub[11] = 0;
       _type_soft_ub[12] = 0;
       _type_soft_ub[13] = 0;
       _type_soft_ub[14] = 0;
       _type_soft_ub[15] = 0;
       _type_soft_ub[16] = 0;
       _type_soft_ub[17] = 0;
       _type_soft_ub[18] = 0;
       _type_soft_ub[19] = 0;
       _type_soft_ub[20] = 0;
       _type_soft_ub[21] = 0;
       _type_soft_ub[22] = 0;
       _type_soft_ub[23] = 0;
       _type_soft_ub[24] = 0;
       _type_soft_ub[25] = 0;
       _type_soft_ub[26] = 0;
       _type_soft_ub[27] = 0;
       _type_soft_ub[28] = 0;
    }
}

void inverse_kinematics_g1_g_soft_weight(const Inverse_kinematics_g1_SolverInfo *_solverinfo, const Inverse_kinematics_g1_Problem *_prob, double _g_soft_weight[4])
{
    
    (void)_solverinfo;
    (void)_prob->param;
    (void)_prob->param_stage;
    
    
    if (_g_soft_weight != NULL) {
       _g_soft_weight[0] = HUGE_VAL;
       _g_soft_weight[1] = HUGE_VAL;
       _g_soft_weight[2] = HUGE_VAL;
       _g_soft_weight[3] = HUGE_VAL;
    }
}

void inverse_kinematics_g1_g_soft_type(const Inverse_kinematics_g1_SolverInfo *_solverinfo, int _g_soft_type[4])
{
    
    (void)_solverinfo;
    
    
    if (_g_soft_type != NULL) {
       _g_soft_type[0] = 0;
       _g_soft_type[1] = 0;
       _g_soft_type[2] = 0;
       _g_soft_type[3] = 0;
    }
}

void inverse_kinematics_g1_fs_soft_weight(const Inverse_kinematics_g1_SolverInfo *_solverinfo, const Inverse_kinematics_g1_Problem *_prob, double _weight_soft_fs[18])
{
    
    (void)_solverinfo;
    (void)_prob->param;
    (void)_prob->param_stage;
    
    
    if (_weight_soft_fs != NULL) {
       _weight_soft_fs[0] = HUGE_VAL;
       _weight_soft_fs[1] = HUGE_VAL;
       _weight_soft_fs[2] = HUGE_VAL;
       _weight_soft_fs[3] = HUGE_VAL;
       _weight_soft_fs[4] = HUGE_VAL;
       _weight_soft_fs[5] = HUGE_VAL;
       _weight_soft_fs[6] = HUGE_VAL;
       _weight_soft_fs[7] = HUGE_VAL;
       _weight_soft_fs[8] = HUGE_VAL;
       _weight_soft_fs[9] = HUGE_VAL;
       _weight_soft_fs[10] = HUGE_VAL;
       _weight_soft_fs[11] = HUGE_VAL;
       _weight_soft_fs[12] = HUGE_VAL;
       _weight_soft_fs[13] = HUGE_VAL;
       _weight_soft_fs[14] = HUGE_VAL;
       _weight_soft_fs[15] = HUGE_VAL;
       _weight_soft_fs[16] = HUGE_VAL;
       _weight_soft_fs[17] = HUGE_VAL;
    }
}

void inverse_kinematics_g1_fs_soft_type(const Inverse_kinematics_g1_SolverInfo *_solverinfo, int _type_soft_fs[18])
{
    
    (void)_solverinfo;
    
    
    if (_type_soft_fs != NULL) {
       _type_soft_fs[0] = 0;
       _type_soft_fs[1] = 0;
       _type_soft_fs[2] = 0;
       _type_soft_fs[3] = 0;
       _type_soft_fs[4] = 0;
       _type_soft_fs[5] = 0;
       _type_soft_fs[6] = 0;
       _type_soft_fs[7] = 0;
       _type_soft_fs[8] = 0;
       _type_soft_fs[9] = 0;
       _type_soft_fs[10] = 0;
       _type_soft_fs[11] = 0;
       _type_soft_fs[12] = 0;
       _type_soft_fs[13] = 0;
       _type_soft_fs[14] = 0;
       _type_soft_fs[15] = 0;
       _type_soft_fs[16] = 0;
       _type_soft_fs[17] = 0;
    }
}

void inverse_kinematics_g1_bfgs_init_hessian(const Inverse_kinematics_g1_SolverInfo *_solverinfo, const Inverse_kinematics_g1_Problem *_prob, double _hess[435])
{
    
    (void)_solverinfo;
    (void)_prob->param;
    (void)_prob->param_stage;
    
    
    if (_hess != NULL) {
       _hess[0] = 1.0;
       _hess[1] = 0.0;
       _hess[2] = 0.0;
       _hess[3] = 0.0;
       _hess[4] = 0.0;
       _hess[5] = 0.0;
       _hess[6] = 0.0;
       _hess[7] = 0.0;
       _hess[8] = 0.0;
       _hess[9] = 0.0;
       _hess[10] = 0.0;
       _hess[11] = 0.0;
       _hess[12] = 0.0;
       _hess[13] = 0.0;
       _hess[14] = 0.0;
       _hess[15] = 0.0;
       _hess[16] = 0.0;
       _hess[17] = 0.0;
       _hess[18] = 0.0;
       _hess[19] = 0.0;
       _hess[20] = 0.0;
       _hess[21] = 0.0;
       _hess[22] = 0.0;
       _hess[23] = 0.0;
       _hess[24] = 0.0;
       _hess[25] = 0.0;
       _hess[26] = 0.0;
       _hess[27] = 0.0;
       _hess[28] = 0.0;
       _hess[29] = 1.0;
       _hess[30] = 0.0;
       _hess[31] = 0.0;
       _hess[32] = 0.0;
       _hess[33] = 0.0;
       _hess[34] = 0.0;
       _hess[35] = 0.0;
       _hess[36] = 0.0;
       _hess[37] = 0.0;
       _hess[38] = 0.0;
       _hess[39] = 0.0;
       _hess[40] = 0.0;
       _hess[41] = 0.0;
       _hess[42] = 0.0;
       _hess[43] = 0.0;
       _hess[44] = 0.0;
       _hess[45] = 0.0;
       _hess[46] = 0.0;
       _hess[47] = 0.0;
       _hess[48] = 0.0;
       _hess[49] = 0.0;
       _hess[50] = 0.0;
       _hess[51] = 0.0;
       _hess[52] = 0.0;
       _hess[53] = 0.0;
       _hess[54] = 0.0;
       _hess[55] = 0.0;
       _hess[56] = 0.0;
       _hess[57] = 1.0;
       _hess[58] = 0.0;
       _hess[59] = 0.0;
       _hess[60] = 0.0;
       _hess[61] = 0.0;
       _hess[62] = 0.0;
       _hess[63] = 0.0;
       _hess[64] = 0.0;
       _hess[65] = 0.0;
       _hess[66] = 0.0;
       _hess[67] = 0.0;
       _hess[68] = 0.0;
       _hess[69] = 0.0;
       _hess[70] = 0.0;
       _hess[71] = 0.0;
       _hess[72] = 0.0;
       _hess[73] = 0.0;
       _hess[74] = 0.0;
       _hess[75] = 0.0;
       _hess[76] = 0.0;
       _hess[77] = 0.0;
       _hess[78] = 0.0;
       _hess[79] = 0.0;
       _hess[80] = 0.0;
       _hess[81] = 0.0;
       _hess[82] = 0.0;
       _hess[83] = 0.0;
       _hess[84] = 1.0;
       _hess[85] = 0.0;
       _hess[86] = 0.0;
       _hess[87] = 0.0;
       _hess[88] = 0.0;
       _hess[89] = 0.0;
       _hess[90] = 0.0;
       _hess[91] = 0.0;
       _hess[92] = 0.0;
       _hess[93] = 0.0;
       _hess[94] = 0.0;
       _hess[95] = 0.0;
       _hess[96] = 0.0;
       _hess[97] = 0.0;
       _hess[98] = 0.0;
       _hess[99] = 0.0;
       _hess[100] = 0.0;
       _hess[101] = 0.0;
       _hess[102] = 0.0;
       _hess[103] = 0.0;
       _hess[104] = 0.0;
       _hess[105] = 0.0;
       _hess[106] = 0.0;
       _hess[107] = 0.0;
       _hess[108] = 0.0;
       _hess[109] = 0.0;
       _hess[110] = 1.0;
       _hess[111] = 0.0;
       _hess[112] = 0.0;
       _hess[113] = 0.0;
       _hess[114] = 0.0;
       _hess[115] = 0.0;
       _hess[116] = 0.0;
       _hess[117] = 0.0;
       _hess[118] = 0.0;
       _hess[119] = 0.0;
       _hess[120] = 0.0;
       _hess[121] = 0.0;
       _hess[122] = 0.0;
       _hess[123] = 0.0;
       _hess[124] = 0.0;
       _hess[125] = 0.0;
       _hess[126] = 0.0;
       _hess[127] = 0.0;
       _hess[128] = 0.0;
       _hess[129] = 0.0;
       _hess[130] = 0.0;
       _hess[131] = 0.0;
       _hess[132] = 0.0;
       _hess[133] = 0.0;
       _hess[134] = 0.0;
       _hess[135] = 1.0;
       _hess[136] = 0.0;
       _hess[137] = 0.0;
       _hess[138] = 0.0;
       _hess[139] = 0.0;
       _hess[140] = 0.0;
       _hess[141] = 0.0;
       _hess[142] = 0.0;
       _hess[143] = 0.0;
       _hess[144] = 0.0;
       _hess[145] = 0.0;
       _hess[146] = 0.0;
       _hess[147] = 0.0;
       _hess[148] = 0.0;
       _hess[149] = 0.0;
       _hess[150] = 0.0;
       _hess[151] = 0.0;
       _hess[152] = 0.0;
       _hess[153] = 0.0;
       _hess[154] = 0.0;
       _hess[155] = 0.0;
       _hess[156] = 0.0;
       _hess[157] = 0.0;
       _hess[158] = 0.0;
       _hess[159] = 1.0;
       _hess[160] = 0.0;
       _hess[161] = 0.0;
       _hess[162] = 0.0;
       _hess[163] = 0.0;
       _hess[164] = 0.0;
       _hess[165] = 0.0;
       _hess[166] = 0.0;
       _hess[167] = 0.0;
       _hess[168] = 0.0;
       _hess[169] = 0.0;
       _hess[170] = 0.0;
       _hess[171] = 0.0;
       _hess[172] = 0.0;
       _hess[173] = 0.0;
       _hess[174] = 0.0;
       _hess[175] = 0.0;
       _hess[176] = 0.0;
       _hess[177] = 0.0;
       _hess[178] = 0.0;
       _hess[179] = 0.0;
       _hess[180] = 0.0;
       _hess[181] = 0.0;
       _hess[182] = 1.0;
       _hess[183] = 0.0;
       _hess[184] = 0.0;
       _hess[185] = 0.0;
       _hess[186] = 0.0;
       _hess[187] = 0.0;
       _hess[188] = 0.0;
       _hess[189] = 0.0;
       _hess[190] = 0.0;
       _hess[191] = 0.0;
       _hess[192] = 0.0;
       _hess[193] = 0.0;
       _hess[194] = 0.0;
       _hess[195] = 0.0;
       _hess[196] = 0.0;
       _hess[197] = 0.0;
       _hess[198] = 0.0;
       _hess[199] = 0.0;
       _hess[200] = 0.0;
       _hess[201] = 0.0;
       _hess[202] = 0.0;
       _hess[203] = 0.0;
       _hess[204] = 1.0;
       _hess[205] = 0.0;
       _hess[206] = 0.0;
       _hess[207] = 0.0;
       _hess[208] = 0.0;
       _hess[209] = 0.0;
       _hess[210] = 0.0;
       _hess[211] = 0.0;
       _hess[212] = 0.0;
       _hess[213] = 0.0;
       _hess[214] = 0.0;
       _hess[215] = 0.0;
       _hess[216] = 0.0;
       _hess[217] = 0.0;
       _hess[218] = 0.0;
       _hess[219] = 0.0;
       _hess[220] = 0.0;
       _hess[221] = 0.0;
       _hess[222] = 0.0;
       _hess[223] = 0.0;
       _hess[224] = 0.0;
       _hess[225] = 1.0;
       _hess[226] = 0.0;
       _hess[227] = 0.0;
       _hess[228] = 0.0;
       _hess[229] = 0.0;
       _hess[230] = 0.0;
       _hess[231] = 0.0;
       _hess[232] = 0.0;
       _hess[233] = 0.0;
       _hess[234] = 0.0;
       _hess[235] = 0.0;
       _hess[236] = 0.0;
       _hess[237] = 0.0;
       _hess[238] = 0.0;
       _hess[239] = 0.0;
       _hess[240] = 0.0;
       _hess[241] = 0.0;
       _hess[242] = 0.0;
       _hess[243] = 0.0;
       _hess[244] = 0.0;
       _hess[245] = 1.0;
       _hess[246] = 0.0;
       _hess[247] = 0.0;
       _hess[248] = 0.0;
       _hess[249] = 0.0;
       _hess[250] = 0.0;
       _hess[251] = 0.0;
       _hess[252] = 0.0;
       _hess[253] = 0.0;
       _hess[254] = 0.0;
       _hess[255] = 0.0;
       _hess[256] = 0.0;
       _hess[257] = 0.0;
       _hess[258] = 0.0;
       _hess[259] = 0.0;
       _hess[260] = 0.0;
       _hess[261] = 0.0;
       _hess[262] = 0.0;
       _hess[263] = 0.0;
       _hess[264] = 1.0;
       _hess[265] = 0.0;
       _hess[266] = 0.0;
       _hess[267] = 0.0;
       _hess[268] = 0.0;
       _hess[269] = 0.0;
       _hess[270] = 0.0;
       _hess[271] = 0.0;
       _hess[272] = 0.0;
       _hess[273] = 0.0;
       _hess[274] = 0.0;
       _hess[275] = 0.0;
       _hess[276] = 0.0;
       _hess[277] = 0.0;
       _hess[278] = 0.0;
       _hess[279] = 0.0;
       _hess[280] = 0.0;
       _hess[281] = 0.0;
       _hess[282] = 1.0;
       _hess[283] = 0.0;
       _hess[284] = 0.0;
       _hess[285] = 0.0;
       _hess[286] = 0.0;
       _hess[287] = 0.0;
       _hess[288] = 0.0;
       _hess[289] = 0.0;
       _hess[290] = 0.0;
       _hess[291] = 0.0;
       _hess[292] = 0.0;
       _hess[293] = 0.0;
       _hess[294] = 0.0;
       _hess[295] = 0.0;
       _hess[296] = 0.0;
       _hess[297] = 0.0;
       _hess[298] = 0.0;
       _hess[299] = 1.0;
       _hess[300] = 0.0;
       _hess[301] = 0.0;
       _hess[302] = 0.0;
       _hess[303] = 0.0;
       _hess[304] = 0.0;
       _hess[305] = 0.0;
       _hess[306] = 0.0;
       _hess[307] = 0.0;
       _hess[308] = 0.0;
       _hess[309] = 0.0;
       _hess[310] = 0.0;
       _hess[311] = 0.0;
       _hess[312] = 0.0;
       _hess[313] = 0.0;
       _hess[314] = 0.0;
       _hess[315] = 1.0;
       _hess[316] = 0.0;
       _hess[317] = 0.0;
       _hess[318] = 0.0;
       _hess[319] = 0.0;
       _hess[320] = 0.0;
       _hess[321] = 0.0;
       _hess[322] = 0.0;
       _hess[323] = 0.0;
       _hess[324] = 0.0;
       _hess[325] = 0.0;
       _hess[326] = 0.0;
       _hess[327] = 0.0;
       _hess[328] = 0.0;
       _hess[329] = 0.0;
       _hess[330] = 1.0;
       _hess[331] = 0.0;
       _hess[332] = 0.0;
       _hess[333] = 0.0;
       _hess[334] = 0.0;
       _hess[335] = 0.0;
       _hess[336] = 0.0;
       _hess[337] = 0.0;
       _hess[338] = 0.0;
       _hess[339] = 0.0;
       _hess[340] = 0.0;
       _hess[341] = 0.0;
       _hess[342] = 0.0;
       _hess[343] = 0.0;
       _hess[344] = 1.0;
       _hess[345] = 0.0;
       _hess[346] = 0.0;
       _hess[347] = 0.0;
       _hess[348] = 0.0;
       _hess[349] = 0.0;
       _hess[350] = 0.0;
       _hess[351] = 0.0;
       _hess[352] = 0.0;
       _hess[353] = 0.0;
       _hess[354] = 0.0;
       _hess[355] = 0.0;
       _hess[356] = 0.0;
       _hess[357] = 1.0;
       _hess[358] = 0.0;
       _hess[359] = 0.0;
       _hess[360] = 0.0;
       _hess[361] = 0.0;
       _hess[362] = 0.0;
       _hess[363] = 0.0;
       _hess[364] = 0.0;
       _hess[365] = 0.0;
       _hess[366] = 0.0;
       _hess[367] = 0.0;
       _hess[368] = 0.0;
       _hess[369] = 1.0;
       _hess[370] = 0.0;
       _hess[371] = 0.0;
       _hess[372] = 0.0;
       _hess[373] = 0.0;
       _hess[374] = 0.0;
       _hess[375] = 0.0;
       _hess[376] = 0.0;
       _hess[377] = 0.0;
       _hess[378] = 0.0;
       _hess[379] = 0.0;
       _hess[380] = 1.0;
       _hess[381] = 0.0;
       _hess[382] = 0.0;
       _hess[383] = 0.0;
       _hess[384] = 0.0;
       _hess[385] = 0.0;
       _hess[386] = 0.0;
       _hess[387] = 0.0;
       _hess[388] = 0.0;
       _hess[389] = 0.0;
       _hess[390] = 1.0;
       _hess[391] = 0.0;
       _hess[392] = 0.0;
       _hess[393] = 0.0;
       _hess[394] = 0.0;
       _hess[395] = 0.0;
       _hess[396] = 0.0;
       _hess[397] = 0.0;
       _hess[398] = 0.0;
       _hess[399] = 1.0;
       _hess[400] = 0.0;
       _hess[401] = 0.0;
       _hess[402] = 0.0;
       _hess[403] = 0.0;
       _hess[404] = 0.0;
       _hess[405] = 0.0;
       _hess[406] = 0.0;
       _hess[407] = 1.0;
       _hess[408] = 0.0;
       _hess[409] = 0.0;
       _hess[410] = 0.0;
       _hess[411] = 0.0;
       _hess[412] = 0.0;
       _hess[413] = 0.0;
       _hess[414] = 1.0;
       _hess[415] = 0.0;
       _hess[416] = 0.0;
       _hess[417] = 0.0;
       _hess[418] = 0.0;
       _hess[419] = 0.0;
       _hess[420] = 1.0;
       _hess[421] = 0.0;
       _hess[422] = 0.0;
       _hess[423] = 0.0;
       _hess[424] = 0.0;
       _hess[425] = 1.0;
       _hess[426] = 0.0;
       _hess[427] = 0.0;
       _hess[428] = 0.0;
       _hess[429] = 1.0;
       _hess[430] = 0.0;
       _hess[431] = 0.0;
       _hess[432] = 1.0;
       _hess[433] = 0.0;
       _hess[434] = 1.0;
    }
}

#ifdef __cplusplus
}
#endif

