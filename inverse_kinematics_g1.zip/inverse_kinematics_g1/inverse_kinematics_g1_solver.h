/* Copyright 2025, RTOPT */

#ifndef INVERSE_KINEMATICS_G1_SOLVER_H_
#define INVERSE_KINEMATICS_G1_SOLVER_H_

# ifdef __cplusplus
extern "C" {
# endif /* ifdef __cplusplus */
#include <stddef.h>

#define problem_temp_defs_START

#define problem_temp_defs_END

#define NAME_define_START

#define NAME_define_END

#ifndef INVERSE_KINEMATICS_G1_PROBLEM_STRUCT
#define INVERSE_KINEMATICS_G1_PROBLEM_STRUCT
typedef struct Inverse_kinematics_g1_Problem
{
    double param[25];
    double *param_stage[1];
    size_t valid_dim_N;
} Inverse_kinematics_g1_Problem;
#endif

#ifndef INVERSE_KINEMATICS_G1_SOLVERINFO_STRUCT
#define INVERSE_KINEMATICS_G1_SOLVERINFO_STRUCT
typedef struct Inverse_kinematics_g1_SolverInfo
{
    int thread_id;
    int stage;
    int iter;
} Inverse_kinematics_g1_SolverInfo;
#endif



typedef struct Inverse_kinematics_g1_PrimalVariable
{
    /* optimization variable */
    double var[1][29];
    double s_lb[1][29];
    double s_ub[1][29];
    double s_soft_lb[1][29];
    double s_soft_ub[1][29];
    double p_soft_lb[1][29];
    double p_soft_ub[1][29];
#if 4 > 0
    double s_g[1][4];
    double p_g[1][4];
    double s_p_g[1][4];
#endif
#if 0 > 0
    double s_gsoc[1][0];
    double p_gsoc[1][0];
    double s_p_gsoc[1][0];
#endif
#if 0 > 0
    double p_f[0][0];
    double n_f[0][0];
    double s_p_f[0][0];
    double s_n_f[0][0];
#endif
#if 18 > 0
    double p_fs[18];
    double n_fs[18];
    double s_p_fs[18];
    double s_n_fs[18];
#endif
#if 0 > 0
    double p_fe[0];
    double n_fe[0];
    double s_p_fe[0];
    double s_n_fe[0];
#endif
} Inverse_kinematics_g1_PrimalVariable;

typedef struct Inverse_kinematics_g1_DualVariable
{
    double z_lb[1][29];
    double z_ub[1][29];
    double z_soft_lb[1][29];
    double z_soft_ub[1][29];
    double z_p_soft_lb[1][29];
    double z_p_soft_ub[1][29];
#if 4 > 0
    double z_g[1][4];
    double z_p_g[1][4];
#endif

#if 0 > 0
    double z_gsoc[1][0];
    double z_p_gsoc[1][0];
#endif

#if 0 > 0
    double y_f[0][0];
    double z_p_f[0][0];
    double z_n_f[0][0];
#endif

#if 18 > 0
    double y_fs[18]; 
    double z_p_fs[18];
    double z_n_fs[18];
#endif
#if 0 > 0
    double y_fe[0];
    double z_p_fe[0];
    double z_n_fe[0];
#endif
} Inverse_kinematics_g1_DualVariable;


typedef struct Inverse_kinematics_g1_WorkSpace
{
    int thread_id;
    Inverse_kinematics_g1_PrimalVariable primal;
    Inverse_kinematics_g1_DualVariable dual;

    /* lagrange hessian, only lower triangular part is stored, column-major order */
    double hessian[1][(29) * (29 + 1) / 2]; 

    char mem[46608];
} Inverse_kinematics_g1_WorkSpace;

typedef struct Inverse_kinematics_g1_Output
{
    /* number of iterations */
    int iter;
    
    /* objective value */
    double obj;

    /* solve time, in seconds */
    double solve_time;

    /* residuals */
    double res_eq;
    double res_ineq;
    double res_stat;
    double res_comp;

    /* primal variables */
    Inverse_kinematics_g1_PrimalVariable primal;
} Inverse_kinematics_g1_Output;

typedef struct Inverse_kinematics_g1_Option
{
    /* initial and target barrier parameter, (0 ~ 1e8] */
    double barrier_init;
    double barrier_target;
    /* 0: monotone barrier strategy, 1: loqo barrier strategy, 2: combined monotone and logo strategy */
    int barrier_strategy;
    /* 0: do not try warm start, 1: try warm start */
    int try_warm_start_barrier;

    /* tolerances */
    double tol_eq; /* equality */
    double tol_ineq; /* inequality */
    double tol_stat; /* stationarity */
    double tol_comp; /* complementarity */
    double tol_step; /* step size */

    /* maximum number of iterations */
    int max_num_iter;

    /* 0: no print, 1: low, 2: medium, 3: high, 4: debug */
    int print_level;

    /* maximum number of bfgs skipping */
    int bfgs_max_num_skipping;

    /* 0: no scaling, 1: user scaling, 2: hessian-based scaling */
    int obj_scaling_method;
    double obj_scaling_factor;

    /* 0.0 - 1.0 */
    double max_stepsize;

    /* 0: no line search, 1: filter line search */
    int line_search_method;
    /* maximum number of line search iterations */
    int line_search_max_num_iter;

    /* relaxation weight when infeasible */
    double infeasibility_relaxation_weight;

    /* regularization */
    double reg_hessian;
    double reg_eq;
    double reg_ineq;
} Inverse_kinematics_g1_Option;

typedef struct Inverse_kinematics_g1_SerializationBuffer
{
    Inverse_kinematics_g1_Problem prob;
    Inverse_kinematics_g1_Option option;
    Inverse_kinematics_g1_WorkSpace workspace;
} Inverse_kinematics_g1_SerializationBuffer;

/* serialization, works only when serialization is enabled in codegen */
/* otherwise, empty functions will be generated */
void inverse_kinematics_g1_serialization_to_buffer(const Inverse_kinematics_g1_Problem * const prob, const Inverse_kinematics_g1_Option * const option, \
    const Inverse_kinematics_g1_WorkSpace * const workspace, Inverse_kinematics_g1_SerializationBuffer * const serialization_buffer);
int inverse_kinematics_g1_serialization_save_buffer_to_file(const Inverse_kinematics_g1_SerializationBuffer * const serialization_buffer, \
    const char * const filename);
int inverse_kinematics_g1_serialization_save_to_file(const Inverse_kinematics_g1_Problem * const prob, const Inverse_kinematics_g1_Option * const option, \
    const Inverse_kinematics_g1_WorkSpace * const workspace, const char * const filename);
int inverse_kinematics_g1_serialization_load_from_file(const char * const filename, Inverse_kinematics_g1_Problem * const prob, \
    Inverse_kinematics_g1_Option * const option, Inverse_kinematics_g1_WorkSpace * const workspace);

/* setup_default_option is duplicated, use init instead */
/* init */
void inverse_kinematics_g1_init(Inverse_kinematics_g1_Problem * const prob, Inverse_kinematics_g1_Option * const option, Inverse_kinematics_g1_WorkSpace * const workspace);
/* solve */
int inverse_kinematics_g1_solve(const Inverse_kinematics_g1_Problem * const prob, const Inverse_kinematics_g1_Option * const option, \
    Inverse_kinematics_g1_WorkSpace * const workspace, Inverse_kinematics_g1_Output * const output);

# ifdef __cplusplus
}
# endif /* ifdef __cplusplus */

#endif