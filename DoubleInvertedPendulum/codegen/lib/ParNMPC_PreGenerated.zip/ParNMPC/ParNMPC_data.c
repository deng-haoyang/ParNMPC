/*
 * File: ParNMPC_data.c
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 21-Jan-2018 01:36:29
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "ParNMPC.h"
#include "ParNMPC_data.h"
#include <stdio.h>
#include "omp.h"
#include "stdio.h"

/* Variable Definitions */
omp_nest_lock_t emlrtNestLockGlobal;

/*
 * File trailer for ParNMPC_data.c
 *
 * [EOF]
 */
