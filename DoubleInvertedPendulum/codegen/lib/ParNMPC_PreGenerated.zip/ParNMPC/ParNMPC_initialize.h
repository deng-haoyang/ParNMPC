/*
 * File: ParNMPC_initialize.h
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 21-Jan-2018 01:36:29
 */

#ifndef PARNMPC_INITIALIZE_H
#define PARNMPC_INITIALIZE_H

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "omp.h"
#include "ParNMPC_types.h"

/* Function Declarations */
extern void ParNMPC_initialize(void);

#endif

/*
 * File trailer for ParNMPC_initialize.h
 *
 * [EOF]
 */
