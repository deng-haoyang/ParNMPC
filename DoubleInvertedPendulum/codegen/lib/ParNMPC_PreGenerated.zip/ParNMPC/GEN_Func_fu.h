/*
 * File: GEN_Func_fu.h
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 21-Jan-2018 01:36:29
 */

#ifndef GEN_FUNC_FU_H
#define GEN_FUNC_FU_H

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "omp.h"
#include "ParNMPC_types.h"

/* Function Declarations */
extern void GEN_Func_fu(const double in1[15], double fu[12]);

#endif

/*
 * File trailer for GEN_Func_fu.h
 *
 * [EOF]
 */
