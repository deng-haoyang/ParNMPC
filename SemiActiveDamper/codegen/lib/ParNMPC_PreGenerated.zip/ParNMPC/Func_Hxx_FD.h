/*
 * File: Func_Hxx_FD.h
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 21-Jan-2018 01:45:16
 */

#ifndef FUNC_HXX_FD_H
#define FUNC_HXX_FD_H

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "omp.h"
#include "ParNMPC_types.h"

/* Function Declarations */
extern void Func_Hxx_FD(const double in1[7], double Hxx[4]);

#endif

/*
 * File trailer for Func_Hxx_FD.h
 *
 * [EOF]
 */
