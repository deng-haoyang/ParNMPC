/*
 * File: GEN_Func_fx_I.h
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 21-Jan-2018 01:45:16
 */

#ifndef GEN_FUNC_FX_I_H
#define GEN_FUNC_FX_I_H

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "omp.h"
#include "ParNMPC_types.h"

/* Function Declarations */
extern void GEN_Func_fx_I(const double in1[7], double fx_I[4]);

#endif

/*
 * File trailer for GEN_Func_fx_I.h
 *
 * [EOF]
 */
